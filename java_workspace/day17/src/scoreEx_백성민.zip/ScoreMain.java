package scoreEx_�鼺��;

public class ScoreMain {

	public static void main(String[] args) {

		new ScoreController().menu();
		
	}

}
