package Damagochi;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;



/*
 * ������� 
 * eat sleep bath study exit /option 
 * 5�� ����Ϸ�  
 * 
 */
public class ExtendTest04_�輼��{
	public static void main(String[] args) {
		new Main();
	}
}

class Main extends JFrame implements ActionListener{
	 ImageIcon inputImage;
	 JLabel jL;	 

	Container contentPane = this.getContentPane(); // �����̳�
	JPanel pane = new JPanel(); // ��
	RoundedButton button1 = new RoundedButton("Game Start");
	RoundedButton button2 = new RoundedButton("Exit");
	CharacterA ch = new CharacterA();
	
	public Main() {
		super("Main menu");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(760, 350, 400, 300); 
		Color colourBG = new Color(0xF2F2F2); 
		pane.setBackground(colourBG);
		pane.setOpaque(true);

		Font fontForButton = new Font("Verdana",Font.BOLD, 15);
		button1.setBackground(Color.BLACK);
		button2.setBackground(Color.BLACK);
		button1.setForeground(colourBG);
		button2.setForeground(colourBG);
		button1.setFont(fontForButton);
		button2.setFont(fontForButton);
		add(button1);
		add(button2);
		button1.setBounds(30, 190, 150, 50);
		button2.setBounds(200, 190, 150, 50);
		
		imageLoad(jL);
		setVisible(true); // ȭ�鿡 ���̱�
		contentPane.add(pane);
		
		// Game Start panel transition
		button1.addActionListener(new ActionListener() {	
			@Override
			public void actionPerformed(ActionEvent e) {
				pane.remove(contentPane);
				setVisible(false);
				new GameStart(ch);
				}
			});
		
		// Exit Button	
		button2.addActionListener(new ActionListener() { 	
			@Override
			public void actionPerformed(ActionEvent e) {
				int temp;
				temp = JOptionPane.showConfirmDialog(contentPane, "Are you sure?", "Exit Game", JOptionPane.YES_NO_OPTION, EXIT_ON_CLOSE);
				if(temp == 0) setVisible(false); 
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {	
	}
	  public void imageLoad(JLabel jL) {
		  inputImage = new ImageIcon("img/main.png");  //�̹��� ���

		  jL = new JLabel("image",inputImage,JLabel.CENTER);
		  jL.setVerticalTextPosition(JLabel.CENTER);
		  jL.setHorizontalTextPosition(JLabel.RIGHT);

		  add(jL);
	  }
}

class GameStart extends JFrame {
	ImageIcon inputImage;
	JLabel jL;	

	Container contentPane = this.getContentPane(); // �����̳�
	JPanel pane = new JPanel(); // ��
	
	RoundedButton buttonExit = new RoundedButton("x");
	RoundedButton buttonEat = new RoundedButton("Eat");
	RoundedButton buttonStudy = new RoundedButton("Study");
	RoundedButton buttonBath = new RoundedButton("Bath");
	RoundedButton buttonSleep = new RoundedButton("Sleep");
	
	// status name tag 
	JLabel dayT = new JLabel("Day "+ 1);	
	JLabel age = new JLabel("Age " + 7);	
	JLabel name = new JLabel("name");
	JLabel level = new JLabel("level");
	JLabel pointAP = new JLabel("apPoint");
	JLabel pointEnergy = new JLabel("energy");
	JLabel pointHunger = new JLabel("hunger");	
	JLabel pointIntelligence = new JLabel("inteli");
	JLabel pointCleanliness = new JLabel("clean");
	
	public GameStart(CharacterA ch) {
		setBounds(760, 350, 400, 300); 
		Color colourBG = new Color(0xF2F2F2); //�̻�
		pane.setBackground(colourBG);
		pane.setOpaque(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //�ݱ��ư ������� ����
				
		Font fontForName = new Font("Verdana",Font.BOLD, 20);
		ch.setName("Blabla");
		RoundedButton nameFrameText = new RoundedButton(ch.getName()+"");
		nameFrameText.setBounds(12, 12, 96, 26);
		nameFrameText.setBackground(colourBG);
		nameFrameText.setFont(fontForName);
		add(nameFrameText);

		// name frame 
		RoundedButton nameFrameIn = new RoundedButton("");
		nameFrameIn.setBounds(12, 12, 96, 26);
		nameFrameIn.setBackground(colourBG);
		add(nameFrameIn);
		RoundedButton nameFrame = new RoundedButton("");
		nameFrame.setBounds(10, 10, 100, 30);
		nameFrame.setBackground(Color.BLACK);
		add(nameFrame);		
		
		// status location control
		int bleedW=15; 
		int bleedH=50;
		
		Font fontForInfo = new Font("Verdana",Font.BOLD, 12);
		add(age);
		age.setBounds(bleedW+52,bleedH-30, 200, 60);
		age.setFont(fontForInfo);
		add(dayT);
		dayT.setBounds(bleedW, bleedH-30, 200, 60);
		dayT.setFont(fontForInfo);
		
		JLabel levelT = new JLabel("Level");
		JLabel pointAPT = new JLabel("AP");
		JLabel pointEnergyT = new JLabel("Energy");
		JLabel pointHungerT = new JLabel("Hunger");	
		JLabel pointIntelligenceT = new JLabel("Clever");
		JLabel pointCleanlinessT = new JLabel("Clean");
		add(levelT);
		add(pointAPT);
		add(pointEnergyT);
		add(pointHungerT);
		add(pointIntelligenceT);
		add(pointCleanlinessT);
		levelT.setBounds(bleedW, bleedH, 200, 60);
		pointAPT.setBounds(bleedW, bleedH+15, 200, 60);
		pointEnergyT.setBounds(bleedW, bleedH+30, 200, 60);
		pointHungerT.setBounds(bleedW, bleedH+45, 200, 60);
		pointIntelligenceT.setBounds(bleedW, bleedH+60, 200, 60);
		pointCleanlinessT.setBounds(bleedW, bleedH+75, 200, 60);
		
		level.setText(ch.getLevel()+"");
		pointAP.setText(ch.getActivePoint()+"");
		pointEnergy.setText(ch.getHunger()+"");
		pointHunger.setText(ch.getHunger()+"");
		pointIntelligence.setText(ch.getIntelligence()+"");
		pointCleanliness.setText(ch.getClean()+"");

		add(level);
		add(pointAP);
		add(pointEnergy);
		add(pointHunger);
		add(pointIntelligence);
		add(pointCleanliness);


		level.setBounds(bleedW+50, bleedH, 200, 60);
		pointAP.setBounds(bleedW+50, bleedH+15, 200, 60);
		pointEnergy.setBounds(bleedW+50, bleedH+30, 200, 60);
		pointHunger.setBounds(bleedW+50, bleedH+45, 200, 60);
		pointIntelligence.setBounds(bleedW+50, bleedH+60, 200, 60);
		pointCleanliness.setBounds(bleedW+50, bleedH+75, 200, 60);
		
		Font fontForButton = new Font("Verdana",Font.BOLD, 15);
		buttonExit.setBackground(Color.BLACK);
		buttonEat.setBackground(Color.BLACK);
		buttonStudy.setBackground(Color.BLACK);
		buttonBath.setBackground(Color.BLACK);
		buttonSleep.setBackground(Color.BLACK);
		buttonExit.setForeground(colourBG);
		buttonEat.setForeground(colourBG);
		buttonStudy.setForeground(colourBG);
		buttonBath.setForeground(colourBG);
		buttonSleep.setForeground(colourBG);

		buttonExit.setFont(fontForButton);
		buttonEat.setFont(fontForButton);
		buttonStudy.setFont(fontForButton);
		buttonBath.setFont(fontForButton);
		buttonSleep.setFont(fontForButton);
	
		add(buttonExit);
		add(buttonEat);
		add(buttonStudy);
		add(buttonBath);
		add(buttonSleep); 
		buttonExit.setBounds(350, 10, 20, 20);
		buttonEat.setBounds(15, 200, 80, 40);
		buttonStudy.setBounds(105, 200, 80, 40);
		buttonBath.setBounds(195, 200, 80, 40);
		buttonSleep.setBounds(285, 200, 80, 40);
		
		//LevelUp();
		imageLoadBasic(jL); // image load
		contentPane.add(pane);	
		setVisible(true); //�⺻�� false
		
		//��ư �̺�Ʈ ó�� 
		buttonExit.addActionListener(new ActionListener() { 	
			@Override
			public void actionPerformed(ActionEvent e) {
				int temp;
				temp = JOptionPane.showConfirmDialog(contentPane, "Are you sure?", "Exit Game", JOptionPane.YES_NO_OPTION, EXIT_ON_CLOSE);
				if(temp == 0) setVisible(false); 
			}
		});
		buttonEat.addActionListener(new ActionListener() { 	
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Hunger +3\nClean -1\nEnergy -1\nAP -1");
				ch.eat();
				setStatusText(ch);	
				death(ch);
				ending(ch);
			}
		});		
		buttonStudy.addActionListener(new ActionListener() { 	
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Clever +1\nHunger -1\nClean -1\nEnergy -1\nAP -1");
				ch.study();
				setStatusText(ch);		
				death(ch);
				ending(ch);
			}
		});
		buttonBath.addActionListener(new ActionListener() { 	
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Clean+3\nHunger -1\nEnergy -1\nAP -1");
				ch.bath();
				setStatusText(ch);	
				death(ch);
				ending(ch);
			}
		});
		buttonSleep.addActionListener(new ActionListener() { 	
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Energy+4\nAP +3\nHunger -1\nClean -1\nEnergy -1");
				ch.sleep();
				setStatusText(ch);	
				death(ch);
				ending(ch);
			}
		});	
	}
	// �ؽ�Ʈ ��ȭ ó��
	void setStatusText(CharacterA ch) {
		age.setText("Age "+ch.getAge()+"");
		dayT.setText("Day "+ch.getNightCount());
		level.setText(ch.getLevel()+"");
		pointAP.setText(ch.getActivePoint()+"");
		pointEnergy.setText(ch.getEnergy()+"");
		pointHunger.setText(ch.getHunger()+"");
		pointIntelligence.setText(ch.getIntelligence()+"");
		pointCleanliness.setText(ch.getClean()+"");
	}
	//���� ���� ���� ����, ���ӿ���
	void death(CharacterA ch) {
		if (ch.isAlive==false) {
			pane.remove(contentPane);
			setVisible(false);
			JOptionPane.showMessageDialog(null, "              Game Over");
			new Frame();
		}
	}
	void ending(CharacterA ch) {
		if (ch.ending==true) {
			pane.remove(contentPane);
			setVisible(false);
			JOptionPane.showMessageDialog(null, "              Game Clear");
			new Frame();
		}
	}
	// image input
	public void imageLoadBasic(JLabel jL) {
		inputImage = new ImageIcon("img/basic1.png");  //�̹��� ���
		jL = new JLabel(inputImage);
		add(jL);
		setVisible(true); // ȭ�鿡 ���̱�
	}	
	// Pop Up Thread ----------- err
	void LevelUp(CharacterA ch) {
		if(ch.getLevel() ==2) {
			JLabel levelUp = new JLabel("Level UP");
			add(levelUp);
			levelUp.setBounds(100, 100, 200, 60);
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			levelUp.setVisible(false);
		}
	}

}




class RoundedButton extends JButton{
	public RoundedButton() { super(); decorate(); } 
	public RoundedButton(String text) { super(text); decorate(); } 
	public RoundedButton(Action action) { super(action); decorate(); } 
	public RoundedButton(Icon icon) { super(icon); decorate(); } 
	public RoundedButton(String text, Icon icon) { super(text, icon); decorate(); }

	protected void decorate() { setBorderPainted(false); setOpaque(false); }

	@Override 
	protected void paintComponent(Graphics g) { 
		int width = getWidth(); 
		int height = getHeight(); 
		
		Graphics2D graphics = (Graphics2D) g; 
		
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); 
		
		if (getModel().isArmed()) { graphics.setColor(getBackground().darker()); } 
		else if (getModel().isRollover()) { 
			graphics.setColor(getBackground().brighter()); 
			} 
		else { 
			graphics.setColor(getBackground()); 
		} 
		
		graphics.fillRoundRect(0, 0, width, height, 10, 10); 
		
		FontMetrics fontMetrics = graphics.getFontMetrics(); 
		Rectangle stringBounds = fontMetrics.getStringBounds(this.getText(), graphics).getBounds(); 
		
		int textX = (width - stringBounds.width) / 2; 
		int textY = (height - stringBounds.height) / 2 + fontMetrics.getAscent(); 
		
		graphics.setColor(getForeground()); 
		graphics.setFont(getFont()); 
		graphics.drawString(getText(), textX, textY); 
		graphics.dispose(); super.paintComponent(g); 
		}
}
