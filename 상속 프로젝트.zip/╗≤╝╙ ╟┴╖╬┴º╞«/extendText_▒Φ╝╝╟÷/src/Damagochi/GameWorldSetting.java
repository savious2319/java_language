package Damagochi;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

// ĳ���� 1,2,3 image select

// ���� ����



public class GameWorldSetting{
	protected String name;
	protected int age=7;
	protected int activePoint=10;
	protected int experience;
	protected int level=1;
	protected boolean ending;
	protected int nightCount=1;
	protected boolean isAlive = true;
	protected int hunger=10;
	protected int energy=10;
	protected int clean=10;
	protected int intelligence=0;

	public GameWorldSetting() {}

	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getActivePoint() {
		return activePoint;
	}
	public void setActivePoint(int activePoint) {
		this.activePoint = activePoint;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public boolean isEnding() {
		return ending;
	}
	public void setEnding(boolean ending) {
		this.ending = ending;
	}
	public int getNightCount() {
		return nightCount;
	}
	public void setNightCount(int nightCount) {
		this.nightCount = nightCount;
	}
	public void setIsAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		while(true)	{
			if(name.length()>7) JOptionPane.showMessageDialog(null, "character limit in 10");
			else break;
		}
		this.name = name;
	}
	public boolean isAlive() {
		return isAlive;
	}
	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}
	public int getHunger() {
		return hunger;
	}
	public void setHunger(int hunger) {
		this.hunger += hunger;
	}
	public int getEnergy() {
		return energy;
	}
	public void setEnergy(int energy) {
		this.energy = energy;
	}
	public int getClean() {
		return clean;
	}
	public void setClean(int clean) {
		this.clean = clean;
	}
	public int getIntelligence() {
		return intelligence;
	}
	public void setIntelligence(int intelligence) {
		this.intelligence = intelligence;
	}
	
	public void NightCountPass() {
		this.nightCount ++;
	}
	public void hungerUpDown(int num) {
		this.hunger += num;
		if(this.hunger > 10) this.hunger = 10;
	}
	public void cleanUpDown(int num) {
		this.clean += num;
		if(this.clean > 10) this.clean = 10;
	}
	public void intelligenceUpDown(int num) {
		this.intelligence += num;
		
	}
	public void energyUpDown(int num) {
		this.energy += num;
		if (this.energy > 10) this.energy = 10; 
	}
	
	void aPUpDown(int num) {
		activePoint += num;
		if (this.activePoint > 10) this.activePoint = 10; 
	}
	void gainExperienceLevelUp() {
		if(experience==5) {
		experience = 0;
		level++;
		}
		else experience++;
	}
	void dayPassed() {	 //20�Ͽ� 1��
		if(nightCount>12) {
			age++;
		}
		nightCount = 0;
	}
	void reachEnding() {
		if(level==5) ending = true;
	}	
	void death() {
		if(hunger == 0 || clean == 0 || energy == 0) setIsAlive(false);
	}
}

class CharacterA extends GameWorldSetting{
	void eat() {
		statusChange();
		hungerUpDown(4);
	}
	void study() {
		statusChange();
		intelligenceUpDown(1);
	}
	void sleep() {
		statusChange();
		energyUpDown(4);
		aPUpDown(4);
	}
	void bath() {
		statusChange();
		cleanUpDown(4);
	}
	
	void statusChange() {
		hungerUpDown(-1);
		cleanUpDown(-1);
		energyUpDown(-1);
		aPUpDown(-1);
		NightCountPass();
		gainExperienceLevelUp();
		death();
		reachEnding();
	}
}

